import React from 'react';
import { Brain, Dumbbell, Salad, Moon } from 'lucide-react';

const RecommendationsCard: React.FC = () => {
  const recommendations = [
    {
      id: '1',
      title: 'Increase Daily Steps',
      description: 'Try to reach 10,000 steps today',
      priority: 'high',
      category: 'exercise',
    },
    {
      id: '2',
      title: 'Improve Sleep Quality',
      description: 'Maintain consistent sleep schedule',
      priority: 'medium',
      category: 'sleep',
    },
  ];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'exercise':
        return <Dumbbell className="w-5 h-5 text-green-500" />;
      case 'diet':
        return <Salad className="w-5 h-5 text-orange-500" />;
      case 'sleep':
        return <Moon className="w-5 h-5 text-purple-500" />;
      case 'mental_health':
        return <Brain className="w-5 h-5 text-blue-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Health Recommendations</h2>
      
      <div className="space-y-4">
        {recommendations.map((rec) => (
          <div key={rec.id} className="flex items-start space-x-3">
            {getCategoryIcon(rec.category)}
            <div>
              <p className="font-semibold">{rec.title}</p>
              <p className="text-sm text-gray-600">{rec.description}</p>
            </div>
          </div>
        ))}
      </div>
      
      <button className="mt-4 w-full bg-gray-50 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-100 transition-colors">
        View All Recommendations
      </button>
    </div>
  );
};

export default RecommendationsCard;