import React from 'react';
import { Heart, Activity, Moon } from 'lucide-react';

const HealthMetricsCard: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Health Metrics</h2>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Heart className="w-5 h-5 text-red-500 mr-2" />
            <span>Heart Rate</span>
          </div>
          <span className="font-semibold">72 bpm</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Activity className="w-5 h-5 text-green-500 mr-2" />
            <span>Steps</span>
          </div>
          <span className="font-semibold">8,432</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Moon className="w-5 h-5 text-purple-500 mr-2" />
            <span>Sleep</span>
          </div>
          <span className="font-semibold">7h 30m</span>
        </div>
      </div>
      
      <button className="mt-4 w-full bg-gray-50 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-100 transition-colors">
        View All Metrics
      </button>
    </div>
  );
};

export default HealthMetricsCard;