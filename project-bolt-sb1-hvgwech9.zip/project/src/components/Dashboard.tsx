import React from 'react';
import { Activity, Calendar, Heart, Brain, Pill as Pills, MessageCircle } from 'lucide-react';
import HealthMetricsCard from './HealthMetricsCard';
import AppointmentsCard from './AppointmentsCard';
import RecommendationsCard from './RecommendationsCard';
import MedicationCard from './MedicationCard';

const Dashboard: React.FC = () => {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Health Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <HealthMetricsCard />
        <AppointmentsCard />
        <RecommendationsCard />
        <MedicationCard />
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <MessageCircle className="w-6 h-6 text-blue-500 mr-2" />
            <h2 className="text-xl font-semibold">Health Assistant</h2>
          </div>
          <button className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition-colors">
            Chat with AI Assistant
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;