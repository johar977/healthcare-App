import React from 'react';
import { Calendar, Video } from 'lucide-react';
import { format } from 'date-fns';

const AppointmentsCard: React.FC = () => {
  const upcomingAppointments = [
    {
      id: '1',
      doctorName: 'Dr. Sarah Johnson',
      specialty: 'Cardiologist',
      date: new Date('2024-03-25T10:00:00'),
      virtual: true,
    },
    {
      id: '2',
      doctorName: 'Dr. Michael Chen',
      specialty: 'General Practitioner',
      date: new Date('2024-03-28T14:30:00'),
      virtual: false,
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Upcoming Appointments</h2>
      
      <div className="space-y-4">
        {upcomingAppointments.map((appointment) => (
          <div key={appointment.id} className="border-l-4 border-blue-500 pl-4 py-2">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold">{appointment.doctorName}</p>
                <p className="text-sm text-gray-600">{appointment.specialty}</p>
                <p className="text-sm text-gray-500">
                  {format(appointment.date, 'MMM d, yyyy h:mm a')}
                </p>
              </div>
              {appointment.virtual && (
                <Video className="w-5 h-5 text-blue-500" />
              )}
            </div>
          </div>
        ))}
      </div>
      
      <button className="mt-4 w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition-colors">
        Schedule Appointment
      </button>
    </div>
  );
};

export default AppointmentsCard;