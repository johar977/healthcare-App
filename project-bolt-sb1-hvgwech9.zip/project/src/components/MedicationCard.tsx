import React from 'react';
import { Pill as Pills, Clock } from 'lucide-react';

const MedicationCard: React.FC = () => {
  const medications = [
    {
      id: '1',
      name: 'Vitamin D',
      dosage: '1000 IU',
      frequency: 'Daily',
      nextDose: new Date(Date.now() + 2 * 60 * 60 * 1000),
    },
    {
      id: '2',
      name: 'Omega-3',
      dosage: '1000mg',
      frequency: 'Daily',
      nextDose: new Date(Date.now() + 5 * 60 * 60 * 1000),
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Medications</h2>
      
      <div className="space-y-4">
        {medications.map((med) => (
          <div key={med.id} className="flex items-start space-x-3">
            <Pills className="w-5 h-5 text-blue-500 mt-1" />
            <div>
              <p className="font-semibold">{med.name}</p>
              <p className="text-sm text-gray-600">{med.dosage} - {med.frequency}</p>
              <div className="flex items-center text-sm text-gray-500 mt-1">
                <Clock className="w-4 h-4 mr-1" />
                <span>Next dose in {Math.round((med.nextDose.getTime() - Date.now()) / (1000 * 60))} minutes</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <button className="mt-4 w-full bg-gray-50 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-100 transition-colors">
        Manage Medications
      </button>
    </div>
  );
};

export default MedicationCard;