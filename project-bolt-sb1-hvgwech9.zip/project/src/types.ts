export interface HealthMetric {
  id: string;
  type: 'heart_rate' | 'steps' | 'sleep' | 'blood_pressure' | 'weight';
  value: number;
  unit: string;
  timestamp: Date;
}

export interface Appointment {
  id: string;
  doctorName: string;
  specialty: string;
  date: Date;
  notes?: string;
  virtual: boolean;
}

export interface HealthRecommendation {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  category: 'exercise' | 'diet' | 'sleep' | 'mental_health';
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  startDate: Date;
  endDate?: Date;
}